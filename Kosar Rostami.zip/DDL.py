import mysql.connector

config = {'user': 'root', 'password': 'password', 'host': 'localhost', 'database': 'UniversityRostami'}

def create_database():
    conn = mysql.connector.connect(user=config['user'], password=config['password'], host=config['host'])
    cursor = conn.cursor()
    cursor.execute("DROP DATABASE IF EXISTS UniversityRostami")
    cursor.execute("CREATE DATABASE UniversityRostami")
    conn.close()

def create_tables():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    #Table for Students
    cursor.execute('''
        CREATE TABLE Students (
            StudentID INT PRIMARY KEY AUTO_INCREMENT,
            FirstName VARCHAR(100) NOT NULL,
            LastName VARCHAR(100) NOT NULL,
            EnrollmentDate DATE NOT NULL,
            Major VARCHAR(100),
            Email VARCHAR(100) UNIQUE NOT NULL
        )
    ''')

    #Table for Professors
    cursor.execute('''
        CREATE TABLE Professors (
            ProfessorID INT PRIMARY KEY AUTO_INCREMENT,
            FirstName VARCHAR(100) NOT NULL,
            LastName VARCHAR(100) NOT NULL,
            Email VARCHAR(100) UNIQUE NOT NULL,
            Department VARCHAR(100) NOT NULL
        )
    ''')

    #Table for Courses
    cursor.execute('''
        CREATE TABLE Courses (
            CourseID INT PRIMARY KEY AUTO_INCREMENT,
            CourseName VARCHAR(100) NOT NULL,
            Credits INT NOT NULL,
            Department VARCHAR(100) NOT NULL
        )
    ''')

    #Table for Classes
    cursor.execute('''
        CREATE TABLE Classes (
            ClassID INT PRIMARY KEY AUTO_INCREMENT,
            CourseID INT NOT NULL,
            ProfessorID INT NOT NULL,
            Schedule VARCHAR(50),
            Capacity INT NOT NULL,
            FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE,
            FOREIGN KEY (ProfessorID) REFERENCES Professors(ProfessorID) ON DELETE CASCADE
        )
    ''')

    #Table for Enrollments
    cursor.execute('''
        CREATE TABLE Enrollments (
            EnrollmentID INT PRIMARY KEY AUTO_INCREMENT,
            StudentID INT NOT NULL,
            ClassID INT NOT NULL,
            EnrollmentDate DATE NOT NULL,
            FOREIGN KEY (StudentID) REFERENCES Students(StudentID) ON DELETE CASCADE,
            FOREIGN KEY (ClassID) REFERENCES Classes(ClassID) ON DELETE CASCADE
        )
    ''')

    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_database()
    create_tables()
