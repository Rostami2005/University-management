import mysql.connector

config = {
    'user': 'root',
    'password': 'password',
    'host': 'localhost',
    'database': 'UniversityRostami'
}

def insert_sample_data():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    #sample students
    sample_students = [
        ('Ali', 'Hosseini', '2023-09-01', 'Computer Science', 'ali.hosseini@example.com'),
        ('Maryam', 'Shahidi', '2022-09-01', 'Mathematics', 'maryam.shahidi@example.com'),
        ('Reza', 'Ghorbani', '2021-09-01', 'Physics', 'reza.ghorbani@example.com')
    ]
    for student in sample_students:
        cursor.execute('''
            INSERT INTO Students (FirstName, LastName, EnrollmentDate, Major, Email)
            VALUES (%s, %s, %s, %s, %s)
        ''', student)

    #sample professors
    sample_professors = [
        ('Sara', 'Karimi', 'sara.karimi@example.com', 'Computer Science'),
        ('Ali', 'Rostami', 'ali.rostami@example.com', 'Mathematics'),
        ('Narges', 'Taheri', 'narges.taheri@example.com', 'Physics')
    ]
    for professor in sample_professors:
        cursor.execute('''
            INSERT INTO Professors (FirstName, LastName, Email, Department)
            VALUES (%s, %s, %s, %s)
        ''', professor)

    #sample courses
    sample_courses = [
        ('Introduction to Programming', 3, 'Computer Science'),
        ('Linear Algebra', 3, 'Mathematics'),
        ('Quantum Mechanics', 4, 'Physics')
    ]
    for course in sample_courses:
        cursor.execute('''
            INSERT INTO Courses (CourseName, Credits, Department)
            VALUES (%s, %s, %s)
        ''', course)

    #sample classes
    sample_classes = [
        (1, 1, 'Monday 10:00-12:00', 30),  #CourseID, ProfessorID, Schedule, Capacity
        (2, 2, 'Tuesday 14:00-16:00', 25),
        (3, 3, 'Wednesday 08:00-10:00', 20)
    ]
    for cls in sample_classes:
        cursor.execute('''
            INSERT INTO Classes (CourseID, ProfessorID, Schedule, Capacity)
            VALUES (%s, %s, %s, %s)
        ''', cls)

    #sample enrollments
    sample_enrollments = [
        (1, 1, '2023-09-10'),  #StudentID, ClassID, EnrollmentDate
        (2, 2, '2023-09-11'),
        (3, 3, '2023-09-12')
    ]
    for enrollment in sample_enrollments:
        cursor.execute('''
            INSERT INTO Enrollments (StudentID, ClassID, EnrollmentDate)
            VALUES (%s, %s, %s)
        ''', enrollment)

    conn.commit()
    conn.close()

if __name__ == "__main__":
    insert_sample_data()
