import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot.util import antiflood
import mysql.connector
from DDL import create_database, create_tables
from DML import insert_sample_data


API_TOKEN = 'Your_token'
bot = telebot.TeleBot(API_TOKEN)

config = {
    'user': 'root',
    'password': 'password',
    'host': 'localhost',
    'database': 'UniversityRostami'
}


def execute_query(query, params=()):
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params)
    conn.commit()
    conn.close()

def listener(messages):
    for m in messages:
        if m.content_type == 'text':
            print(f'{m.chat.first_name} [{m.chat.id}]: {m.text}')

bot.set_update_listener(listener)


def send_message(*args, **kwargs):
    try:
        antiflood(bot.send_message, *args, **kwargs)
    except Exception as e:
        print('Error happened', e)


def fetch_query(query, params=()):
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params)
    result = cursor.fetchall()
    conn.close()
    return result

@bot.message_handler(commands=['start'])
def start(message):
    markup = InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton("ثبت دانشجوی جدید", callback_data="new_student")
    btn2 = InlineKeyboardButton("مشاهده اساتید", callback_data="view_professors")
    btn3 = InlineKeyboardButton("ثبت‌نام در کلاس", callback_data="enroll_class")
    btn4 = InlineKeyboardButton("مشاهده کلاس‌ها", callback_data="view_classes")

    markup.add(btn1, btn2)
    markup.add(btn3, btn4)

    bot.send_message(message.chat.id, 'به سیستم مدیریت دانشگاه خوش آمدید! لطفاً یک گزینه را انتخاب کنید:', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_query_handler(call):
    cid = call.message.chat.id
    mid = call.message.message_id
    data = call.data

    if data == 'new_student':
        bot.send_message(cid, "لطفاً نام دانشجو را وارد کنید:")
        bot.register_next_step_handler(call.message, process_student_first_name)

    elif data == 'view_professors':
        professors = fetch_query("SELECT FirstName, LastName, Department FROM Professors")
        professors_text = "\nلیست اساتید:\n" + "\n".join([f"{p['FirstName']} {p['LastName']} - گروه: {p['Department']}" for p in professors])
        add_back_to_main_button(cid, mid, professors_text)

    elif data == 'enroll_class':
        bot.send_message(cid, "لطفاً شناسه دانشجو را وارد کنید:")
        bot.register_next_step_handler(call.message, process_student_id_for_enrollment)

    elif data == 'view_classes':
        classes = fetch_query("SELECT c.ClassID, co.CourseName, p.FirstName, p.LastName, c.Schedule FROM Classes c JOIN Courses co ON c.CourseID = co.CourseID JOIN Professors p ON c.ProfessorID = p.ProfessorID")
        classes_text = "\nلیست کلاس‌ها:\n" + "\n".join([f"کلاس {c['ClassID']}: {c['CourseName']} - استاد: {c['FirstName']} {c['LastName']} - زمان: {c['Schedule']}" for c in classes])
        add_back_to_main_button(cid, mid, classes_text)

    elif data == 'back_to_main':
        start(call.message)

def add_back_to_main_button(cid, mid, text):
    markup = InlineKeyboardMarkup()
    back_button = InlineKeyboardButton("بازگشت به منوی اصلی", callback_data="back_to_main")
    markup.add(back_button)
    bot.edit_message_text(text, chat_id=cid, message_id=mid, reply_markup=markup)


def process_student_first_name(message):
    first_name = message.text
    bot.send_message(message.chat.id, "لطفاً نام خانوادگی دانشجو را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_student_last_name(first_name, msg))


def process_student_last_name(first_name, message):
    last_name = message.text
    bot.send_message(message.chat.id, "لطفاً تاریخ ثبت‌نام را به فرمت YYYY-MM-DD وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_student_enrollment_date(first_name, last_name, msg))


def process_student_enrollment_date(first_name, last_name, message):
    enrollment_date = message.text
    bot.send_message(message.chat.id, "لطفاً رشته دانشجو را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_student_major(first_name, last_name, enrollment_date, msg))


def process_student_major(first_name, last_name, enrollment_date, message):
    major = message.text
    bot.send_message(message.chat.id, "لطفاً ایمیل دانشجو را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: finalize_student_registration(first_name, last_name, enrollment_date, major, msg))


def finalize_student_registration(first_name, last_name, enrollment_date, major, message):
    email = message.text
    execute_query('''
        INSERT INTO Students (FirstName, LastName, EnrollmentDate, Major, Email)
        VALUES (%s, %s, %s, %s, %s)
    ''', (first_name, last_name, enrollment_date, major, email))
    bot.send_message(message.chat.id, "ثبت دانشجوی جدید با موفقیت انجام شد.")
    start(message)


def process_student_id_for_enrollment(message):
    student_id = message.text
    bot.send_message(message.chat.id, "لطفاً شناسه کلاس را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: finalize_enrollment(student_id, msg))


def finalize_enrollment(student_id, message):
    class_id = message.text
    execute_query('''
        INSERT INTO Enrollments (StudentID, ClassID, EnrollmentDate)
        VALUES (%s, %s, CURDATE())
    ''', (student_id, class_id))
    bot.send_message(message.chat.id, "ثبت‌نام دانشجو در کلاس با موفقیت انجام شد.")
    start(message)


@bot.message_handler(commands=['help'])
def command_help_handler(message):
    cid = message.chat.id
    link = f'https://stdn2.iau.ir/Student/{cid}'
    send_message(cid, f'جهت انتخاب واحد ترم ۴۰۳۲ به آموزشیار مراجعه فرمایید:\n{link}')


if __name__ == '__main__':
    bot.polling(none_stop=True)
